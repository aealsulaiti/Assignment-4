# Multiplication Table Generator

## Overview

Welcome to the Multiplication Table Generator! This C++ console application allows you to create custom multiplication tables based on user input. The program prompts the user to specify the range of numbers for the multiplication table and the range of multipliers. After generating a multiplication table, it asks if the user wants to create another one.

## How to Use

1. **Clone the Repository:**

2. **Compile and Run:**

   - Compile the C++ code using a C++ compiler (e.g., g++).

   - Run the compiled executable.

   

3. **Enter Ranges:**

   - Enter the starting and ending ranges for the multiplication table.
   - Enter the starting and ending ranges for multipliers.

4. **View Multiplication Table:**

   - The application will display the multiplication table based on the specified ranges.

5. **Repeat or Exit:**

   - After generating a table, the program asks if the user wants to create another one.
   - Type `y` or `Y` for yes, and the process will repeat.
   - Type `n` or `N` for no to exit the program.

## Output

![a86be861-36f1-4fde-b639-5e88a36705e9](C:\Users\pc\Downloads\a86be861-36f1-4fde-b639-5e88a36705e9.jpeg)

![c3680c93-bcf9-4341-bf13-d629632ceb57](C:\Users\pc\Downloads\c3680c93-bcf9-4341-bf13-d629632ceb57.jpeg)