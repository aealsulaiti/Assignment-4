#include <iostream>
#include <iomanip>

int main() {
    char createAnother;

    do {
        int startRange, endRange, startMultiplier, endMultiplier;

        // Get user input for the range of numbers to create a multiplication table on
        std::cout << "Enter the starting range for Multiplication Table: ";
        std::cin >> startRange;

        std::cout << "Enter the ending range for Multiplication Table: ";
        std::cin >> endRange;

        // Get user input for the range of multipliers
        std::cout << "Enter the starting range for multiplying the numbers in Multiplication Table: ";
        std::cin >> startMultiplier;

        std::cout << "Enter the ending range for multiplying the numbers in Multiplication Table: ";
        std::cin >> endMultiplier;

        // Display the multiplication table
        std::cout << "\nHere is the multiplication table for " << startRange << " to " << endRange
                  << " in the range of " << startMultiplier << " to " << endMultiplier << "\n";

        // Display column headers
        std::cout << std::setw(3) << "X";
        for (int j = startMultiplier; j <= endMultiplier; ++j) {
            std::cout << std::setw(5) << j;
        }
        std::cout << "\n";

        // Display the multiplication table
        for (int i = startRange; i <= endRange; ++i) {
            std::cout << std::setw(3) << i;
            for (int j = startMultiplier; j <= endMultiplier; ++j) {
                std::cout << std::setw(5) << (i * j);
            }
            std::cout << "\n";
        }

        // Ask the user if they want to create another multiplication table
        std::cout << "\nDo you want to create another multiplication table? (y/n): ";
        std::cin >> createAnother;

    } while (createAnother == 'y' || createAnother == 'Y');

    std::cout << "Thank you for using the multiplication table generator. Exiting...\n";

    return 0;
}
